const mongoose = require("mongoose");

const Client = require("../models/Client");
const Material = require("../models/Material");

const isValidObjectId = (id) => mongoose.Types.ObjectId.isValid(id);

const allowedUnits = [
  "PCS",
  "KG",
  "TON",
  "BAG",
  "METER",
  "CUBIC_METER",
  "LITER",
  "OTHER",
];

const allowedStatuses = ["ACTIVE", "INACTIVE"];
const maxGstRate = 28;

const isFiniteNumber = (value) => (
  typeof value === "number" && Number.isFinite(value)
);

const validateMoney = (value, fieldName, maxValue) => {
  if (!isFiniteNumber(value)) {
    return `${fieldName} must be a valid number`;
  }

  if (value < 0) {
    return `${fieldName} cannot be negative`;
  }

  if (maxValue !== undefined && value > maxValue) {
    return `${fieldName} cannot be greater than ${maxValue}`;
  }

  return null;
};

const assignTrimmedString = (target, key, value, label) => {
  if (value === undefined) {
    return null;
  }

  if (typeof value !== "string" || !value.trim()) {
    return `${label} cannot be empty`;
  }

  target[key] = value.trim();
  return null;
};

const findOrganizationClient = async (clientId, organizationId) => {
  if (!clientId) {
    return {
      error: {
        status: 400,
        message: "Client id is required",
      },
    };
  }

  if (!isValidObjectId(clientId)) {
    return {
      error: {
        status: 400,
        message: "Invalid client id",
      },
    };
  }

  const client = await Client.findOne({
    _id: clientId,
    organizationId,
  }).lean();

  if (!client) {
    return {
      error: {
        status: 404,
        message: "Client not found",
      },
    };
  }

  return {
    client,
  };
};


// ======================================================
// CREATE MATERIAL
// ======================================================

const createMaterial = async (req, res) => {
  try {
    const {
      clientId,
      name,
      description,
      unit,
      defaultRate,
      gstRate,
      status,
    } = req.body || {};

    const { error: clientError } = await findOrganizationClient(
      clientId,
      req.user.organizationId
    );

    if (clientError) {
      return res.status(clientError.status).json({
        success: false,
        message: clientError.message,
      });
    }

    if (!name || typeof name !== "string" || !name.trim()) {
      return res.status(400).json({
        success: false,
        message: "Material name is required",
      });
    }

    if (!allowedUnits.includes(unit)) {
      return res.status(400).json({
        success: false,
        message: "Invalid unit",
      });
    }

    if (status !== undefined && !allowedStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Invalid status",
      });
    }

    const rateError = validateMoney(
      defaultRate === undefined ? 0 : defaultRate,
      "Default rate"
    );

    if (rateError) {
      return res.status(400).json({
        success: false,
        message: rateError,
      });
    }

    const gstError = validateMoney(
      gstRate === undefined ? 0 : gstRate,
      "GST rate",
      maxGstRate
    );

    if (gstError) {
      return res.status(400).json({
        success: false,
        message: gstError,
      });
    }

    const materialData = {
      organizationId: req.user.organizationId,
      clientId,
      name: name.trim(),
      unit,
      defaultRate: defaultRate === undefined ? 0 : defaultRate,
      gstRate: gstRate === undefined ? 0 : gstRate,
    };

    const descriptionError = assignTrimmedString(
      materialData,
      "description",
      description,
      "Description"
    );

    if (descriptionError) {
      return res.status(400).json({
        success: false,
        message: descriptionError,
      });
    }

    if (status !== undefined) {
      materialData.status = status;
    }

    const material = await Material.create(materialData);

    return res.status(201).json({
      success: true,
      message: "Material created successfully",
      data: material,
    });

  } catch (error) {

    console.error("Create material error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to create material",
    });
  }
};


// ======================================================
// GET ALL MATERIALS
// ======================================================

const getMaterials = async (req, res) => {
  try {
    const query = {
      organizationId: req.user.organizationId,
    };

    if (req.query.clientId) {
      const { error: clientError } = await findOrganizationClient(
        req.query.clientId,
        req.user.organizationId
      );

      if (clientError) {
        return res.status(clientError.status).json({
          success: false,
          message: clientError.message,
        });
      }

      query.clientId = req.query.clientId;
    }

    const materials = await Material.find(query)
      .sort({ createdAt: -1 })
      .lean();

    return res.status(200).json({
      success: true,
      count: materials.length,
      data: materials,
    });

  } catch (error) {

    console.error("Get materials error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch materials",
    });
  }
};


// ======================================================
// GET SINGLE MATERIAL
// ======================================================

const getMaterialById = async (req, res) => {
  try {
    if (!isValidObjectId(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid material id",
      });
    }

    const material = await Material.findOne({
      _id: req.params.id,
      organizationId: req.user.organizationId,
    }).lean();

    if (!material) {
      return res.status(404).json({
        success: false,
        message: "Material not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: material,
    });

  } catch (error) {

    console.error("Get material error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to fetch material",
    });
  }
};


// ======================================================
// UPDATE MATERIAL
// ======================================================

const updateMaterial = async (req, res) => {
  try {
    if (!isValidObjectId(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid material id",
      });
    }

    const {
      clientId,
      name,
      description,
      unit,
      defaultRate,
      gstRate,
    } = req.body || {};

    const updateData = {};

    if (clientId !== undefined) {
      const { error: clientError } = await findOrganizationClient(
        clientId,
        req.user.organizationId
      );

      if (clientError) {
        return res.status(clientError.status).json({
          success: false,
          message: clientError.message,
        });
      }

      updateData.clientId = clientId;
    }

    const nameError = assignTrimmedString(
      updateData,
      "name",
      name,
      "Material name"
    );

    if (nameError) {
      return res.status(400).json({
        success: false,
        message: nameError,
      });
    }

    const descriptionError = assignTrimmedString(
      updateData,
      "description",
      description,
      "Description"
    );

    if (descriptionError) {
      return res.status(400).json({
        success: false,
        message: descriptionError,
      });
    }

    if (unit !== undefined) {
      if (!allowedUnits.includes(unit)) {
        return res.status(400).json({
          success: false,
          message: "Invalid unit",
        });
      }

      updateData.unit = unit;
    }

    if (defaultRate !== undefined) {
      const rateError = validateMoney(defaultRate, "Default rate");

      if (rateError) {
        return res.status(400).json({
          success: false,
          message: rateError,
        });
      }

      updateData.defaultRate = defaultRate;
    }

    if (gstRate !== undefined) {
      const gstError = validateMoney(gstRate, "GST rate", maxGstRate);

      if (gstError) {
        return res.status(400).json({
          success: false,
          message: gstError,
        });
      }

      updateData.gstRate = gstRate;
    }

    if (!Object.keys(updateData).length) {
      return res.status(400).json({
        success: false,
        message: "No valid fields supplied",
      });
    }

    const material = await Material.findOneAndUpdate(
      {
        _id: req.params.id,
        organizationId: req.user.organizationId,
      },
      updateData,
      {
        returnDocument: "after",
        runValidators: true,
      }
    );

    if (!material) {
      return res.status(404).json({
        success: false,
        message: "Material not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Material updated successfully",
      data: material,
    });

  } catch (error) {

    console.error("Update material error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to update material",
    });
  }
};


// ======================================================
// CHANGE MATERIAL STATUS
// ======================================================

const updateMaterialStatus = async (req, res) => {
  try {
    if (!isValidObjectId(req.params.id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid material id",
      });
    }

    const { status } = req.body || {};

    if (!allowedStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Invalid status",
      });
    }

    const material = await Material.findOneAndUpdate(
      {
        _id: req.params.id,
        organizationId: req.user.organizationId,
      },
      {
        status,
      },
      {
        returnDocument: "after",
        runValidators: true,
      }
    );

    if (!material) {
      return res.status(404).json({
        success: false,
        message: "Material not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Material status updated",
      data: material,
    });

  } catch (error) {

    console.error("Update material status error:", error);

    return res.status(500).json({
      success: false,
      message: "Failed to update material status",
    });
  }
};


module.exports = {
  createMaterial,
  getMaterials,
  getMaterialById,
  updateMaterial,
  updateMaterialStatus,
};
